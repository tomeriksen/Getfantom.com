New to SASS?

SASS is a CSS PreProcessor, Its like the source code of CSS File which is located in /css folder.

Read more about SASS here : http://sass-lang.com/

You don't need the SASS Folder in Production. Its only for development. If you know how to edit SASS Files,
You may use this folder. Otherwise you can edit the CSS Folder Directly.

SASS is not Mandatory.


Thanks a lot.
~Surjith